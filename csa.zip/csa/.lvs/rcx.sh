#!/bin/ksh
# This script was generated Mon Feb 24 15:20:20 2025 by:
#
# Program: /home/installs/QUANTUS211/tools.lnx86/extraction/bin/64bit//RCXspice
# Version: 21.1.0-p101
# Created: Wed Mar 17 18:53:08 PDT 2021
#
#/home/installs/QUANTUS211/tools.lnx86/extraction/bin/64bit//RCXspice \
#	-techdir /home/installs/FOUNDRY/analog/180nm/pv/assura/rcx -newlvs \
#	/home/internals/workshop_179/csa/lvs.xcn -assura_run_dir \
#	/home/internals/workshop_179/csa -assura_run_name lvs -rcxdir \
#	/home/internals/workshop_179/csa/lvs -xy_coordinates c,r -type full \
#	-temperature 25.0 -tempdir \
#	/home/internals/workshop_179/csa/lvs/rcx_temp -sub_node_char # \
#	-res_models no -parasitic_res_models comment -parasitic_cap_models \
#	yes -output_net_name_space layout -output_hierarchy_delimiter / \
#	-output /home/internals/workshop_179/csa/lvs/extview.tmp \
#	-net_name_space layout -minR 0.001 -max_merged_via_size auto \
#	-max_fracture_length infinite -macro_cell -m_factorR infinite \
#	-lvs_source assura -ignore_gate_diffusion_fringing_cap \
#	-hierarchy_delimiter / -fracture_length_units MICRONS -extract res \
#	-df2 -cap_models no -array_vias_spacing auto
set -e
set -v
##=======================================================
##ADD_EXPLICIT_VIAS=N
##ADD_BULK_TERMINAL=N
##AGDS_FILE=/dev/null
##AGDS_LAYER_MAP_FILE=/dev/null
##HCCI_DEV_PROP_FILE=/dev/null
##AGDS_SPICE_FILE=/dev/null
##AGDS_TEXT_LAYERS=
##ARRAY_VIAS_SPACING=
##ASSURA_RUN_DIR=/home/internals/workshop_179/csa
##ASSURA_RUN_NAME=lvs
##BLACK_BOX_CELLS=/dev/null
##BREAK_WIDTH=
##CAP_COUPLING_FACTOR=1.0
##CAP_EXTRACT_MODE=decoupled
##CAP_GROUND=gnd!
##CAP_MODELS=no
##DANGLINGR=N
##DENSITY_CHECK_METHOD=P
##DELETE_OUTPUT_FILE=N
##DEVICE_FINGER_DELIMITER='@'
##DF2=Y
##DRACULA_RUN_DIR=
##DRACULA_RUN_NAME=
##ENABLESENSITIVITYEXTRACTION=N
##EXCLUDE_FLOAT_LIMIT=
##EXCLUDE_FLOAT_DECOPULING_FACTOR=
##EXCLUDE_FLOATING_NETS=N
##EXCLUDE_NETS_REDUCERC=/dev/null
##EXCLUDE_SELF_CAPS=N
##IGNORE_GATE_DIFFUSION_FRINGING_CAP=Y
##EXTRACT=res
##EXTRACT_MOS_DIFFUSION_AP=N
##EXTRACT_MOS_DIFFUSION_HIGH=
##EXTRACT_MOS_DIFFUSION_RES=N
##FILTER_SIZE=2.0
##FIXED_NETS_FILE=/dev/null
##FMAX=
##FRACTURE_LENGTH_UNITS=MICRONS
##FREQUENCY_FILE=/dev/null
##GROUND_NETS=
##GROUND_NETS_FILE=/dev/null
##GROUND_SUBSTRATE_FLOATING_NETS=N
##HCCI_DEV_PROP=7
##HCCI_INST_PROP=6
##HCCI_NET_PROP=5
##HCCI_RULE_FILE=
##HCCI_RUN_DIR=
##HCCI_RUN_NAME=
##HEADER_FILE=/dev/null
##HIERARCHY_DELIMITER='/'
##OUTPUT_HIERARCHY_DELIMITER='/'
##HRCX_CELLS_FILE=/dev/null
##IMPORT_GLOBALS=Y
##LADDER_NETWORK=N
##LVS_SOURCE=assura
##M_FACTORR=infinite
##M_FACTORW=N
##MACRO_CELL=Y
##MAX_FRACTURE_LENGTH=infinite
##MAX_SIGNALS=
##MERGE_PARALLEL_R=N
##MERGE_PARALLEL_VIA=N
##MINC=
##MINC_BY_PERCENTAGE=
##MINR=0.001
##NET_NAME_SPACE=layout
##NETS_FILE=/dev/null
##OUTPUT=/home/internals/workshop_179/csa/lvs/extview.tmp
##OUTPUT_NET_NAME_SPACE=layout
##PARASITIC_BLOCKING_DEVICE_CELLS_TYPE=gray
##PARASITIC_CAP_MODELS=yes
##PARASITIC_RES_MODELS=comment
##PARASITIC_RES_LENGTH=N
##PARASITIC_RES_WIDTH=N
##PARASITIC_RES_WIDTH_DRAWN=N
##PARASITIC_RES_UNIT=N
##PARTIAL_CAP_BLOCKING=N
##PEEC=N
##PIN_ORDER_FILE=/dev/null
##PIPE_ADVGEN=
##PIPE_SPICE2DB=
##POWER_NETS=
##POWER_NETS_FILE=/dev/null
##RC_FREQUENCY=
##RCXDIR=/home/internals/workshop_179/csa/lvs
##RCXFS_HIGH=N
##RCXFS_NETS_FILE=
##RCXFS_TYPE=none
##RCXFS_CUTOFF_DISTANCE=
##RCXFS_CUTOFF_DISTANCE=
##RCXFS_CUTOFF_DISTANCE=
##RCXFS_CUTOFF_DISTANCE=
##RCXFS_CUTOFF_DISTANCE=
##RCXFS_VIA_OFF=N
##REDUCERC=N
##REGION_LIMIT=
##RES_MODELS=no
##RISE_TIME=
##SAVE_FILL_SHAPES=N
##SINGLE_CAP_EDSPF=N
##SHOW_DIODES=N
##SKIN_FREQUENCY=
##SPEF=N
##SPEF_UNITS=
##SPLIT_PINS=N
##FORCE_SUBCELL_PIN_ORDERS=N
##SPLIT_PINS_DISTANCE=
##SUB_NODE_CHAR='#'
##SUBSTRATE_PROFILE=/dev/null
##SUBSTRATE_STAMPING_OFF=N
##TEMPDIR=/home/internals/workshop_179/csa/lvs/rcx_temp
##TEMPERATURE=25.0
##TYPE=full
##USER_REGION=/dev/null
##VARIANT_CELL_FILE=/dev/null
##VIA_EFFECT_OFF=N
##VIRTUAL_FILL=
##XREF=/dev/null,/dev/null
##XY_COORDINATES=c,r
##=======================================================

CASE_SENSITIVE=TRUE
export CASE_SENSITIVE
QRC_MOS_LW_PRECISION=y
export QRC_MOS_LW_PRECISION
TEMPDIR=`setTempDir /home/internals/workshop_179/csa/lvs/rcx_temp`
export TEMPDIR
DEVICE_FINGER_DELIMITER='@'
HIERARCHY_DELIMITER='/'
OUTPUT_HIERARCHY_DELIMITER='/'
cd /home/internals/workshop_179/csa/lvs
cat <<ENDCAT> caps2dversion
* caps2d version: 10
ENDCAT
cat <<ENDCAT> flattransUnit.info
meters
ENDCAT
QRC=Y
export QRC
cat <<ENDCAT> topcellxcn.info
/home/internals/workshop_179/csa/lvs.xcn
ENDCAT

#==========================================================#
# Generate RCX input data from Assura LVS database
#==========================================================#

GOALIE2DIR=/home/installs/QUANTUS211/tools.lnx86/extraction/bin
export GOALIE2DIR
vdbToRcx /home/internals/workshop_179/csa lvs -unit meters -mFactorR -- -V1 \
	-H satfile -r /home/internals/workshop_179/csa/lvs.xcn -df2 -xgl
GOALIE2DIR=/home/installs/QUANTUS211/tools.lnx86/extraction/bin/64bit/
export GOALIE2DIR
geom NMOS_MOS_21 NSDterm - NMOS_MOS_21,10,i,1
geom PMOS_MOS_27 PSDterm - PMOS_MOS_27,10,i,1

#==========================================================#
# Generate power list
#==========================================================#

cat global.net > power_list

#==========================================================#
# Ensure vias do not extend beyond routing
#==========================================================#

geom -V POLYcont M1term POLYterm - POLYcont,111,i,2
geom -V PSDcont M1term PSDterm - PSDcont,111,i,2
geom -V NSDcont M1term NSDterm - NSDcont,111,i,2

#==========================================================#
# Flatten net file, routing, via and device layers
#==========================================================#

SAVEDIR=`beginFlattenInputs`
export SAVEDIR
/bin/mv -f NET h_NET
flatnet -V -li -h '/' h_NET NET
netprint -V -N1 power_list:power_list_nums NET
flattenTransistorData NMOS_MOS_21 meters
flattenTransistorData PMOS_MOS_27 meters
flattenLayers -m M1term POLYterm PSDterm NSDterm PSUB NWELLterm POLYcont \
	PSDcont NSDcont NWVIA SUBVIA
endFlattenInputs
reconnect -float floatlvsnetsfile -tf NMOS_MOS_21,PMOS_MOS_27 -probe \
	Metal1_pintext:M1term:Metal1_pintext_fvia
geom NMOS_MOS_21,PMOS_MOS_27 - qrcgate,1,i,1
iprint -imerge power_list_nums floatlvsnetsfile power_list_nums2
mv power_list_nums power_list_nums_orig
cp power_list_nums2 power_list_nums 

#==========================================================#
# Segregate interconnect into resistive and non-resistive
#==========================================================#

selectNetsByNumber power_list_nums M1term p_rM1term np_rM1term
selectNetsByNumber power_list_nums NSDterm p_rNSDterm np_rNSDterm
selectNetsByNumber power_list_nums POLYterm p_rPOLYterm np_rPOLYterm
selectNetsByNumber power_list_nums PSDterm p_rPSDterm np_rPSDterm
selectNetsByNumber power_list_nums NWVIA p_rNWVIA np_rNWVIA
selectNetsByNumber power_list_nums NWELLterm p_rNWELLterm np_rNWELLterm
selectNetsByNumber power_list_nums SUBVIA p_rSUBVIA np_rSUBVIA
selectNetsByNumber power_list_nums PSUB p_rPSUB np_rPSUB
selectNetsByNumber power_list_nums POLYcont p_rPOLYcont np_rPOLYcont
mv power_list_nums_orig power_list_nums

#==========================================================#
# Create resistor cut regions between resistive
# interconnect levels
#==========================================================#

mergevia -V -tech /home/installs/FOUNDRY/analog/180nm/pv/assura/rcx -cnt \
	np_rPOLYcont rPOLYcont - np_rM1term np_rPOLYterm

#==========================================================#
# Create resistive interconnect MOSFET terminals
#==========================================================#

createNRMosfetGateTerminal NMOS_MOS_21 np_rPOLYterm NMOS_MOS_21_mgvia
createNRMosfetGateTerminal PMOS_MOS_27 np_rPOLYterm PMOS_MOS_27_mgvia

#==========================================================#
# Assign net numbers to cut regions
#==========================================================#

connect -V -relocate NET np_rPSDterm:np_rPSDterm.conn \
	np_rNSDterm:np_rNSDterm.conn rPOLYcont NMOS_MOS_21_mgvia \
	PMOS_MOS_27_mgvia - -

#==========================================================#
# Assign net numbers to resistor vias
#==========================================================#

geom -V NSDcont np_rNSDterm.conn - tmp_rNSDcont,11,i,2
mergevia -V -i -tech /home/installs/FOUNDRY/analog/180nm/pv/assura/rcx -cnt \
	tmp_rNSDcont rNSDcont - np_rM1term np_rNSDterm
/bin/rm -f tmp_rNSDcont
geom -V PSDcont np_rPSDterm.conn - tmp_rPSDcont,11,i,2
mergevia -V -i -tech /home/installs/FOUNDRY/analog/180nm/pv/assura/rcx -cnt \
	tmp_rPSDcont rPSDcont - np_rM1term np_rPSDterm
/bin/rm -f tmp_rPSDcont

#==========================================================#
# Assign net numbers to nonresistive layers
#==========================================================#

epick -V -reo -e rNSDcont -e rPSDcont np_rNSDterm.conn tmp_NSDterm
epick -V -reo -e tmp_NSDterm -c np_rNSDterm.conn tmp1_NSDterm
geom -V tmp1_NSDterm np_rNSDterm - tmp1_NSDterm,11,i,2
geom -V tmp_NSDterm,tmp1_NSDterm - np_rNSDterm,1,i,1
/bin/rm -f tmp_NSDterm tmp1_NSDterm
epick -V -reo -e rNSDcont -e rPSDcont np_rPSDterm.conn tmp_PSDterm
epick -V -reo -e tmp_PSDterm -c np_rPSDterm.conn tmp1_PSDterm
geom -V tmp1_PSDterm np_rPSDterm - tmp1_PSDterm,11,i,2
geom -V tmp_PSDterm,tmp1_PSDterm - np_rPSDterm,1,i,1
/bin/rm -f tmp_PSDterm tmp1_PSDterm

#==========================================================#
# Process text layers
#==========================================================#

flatlabel -V  -tc -F -l flatlabel.info Metal1_pintext L1T0
# 1 np_rPOLYterm
# 2 np_rM1term

#==========================================================#
# Parasitic R extraction with default precision
#==========================================================#

rex -V -m -pd -I'#' -tech /home/installs/FOUNDRY/analog/180nm/pv/assura/rcx \
	-map p2elayermapfile -N NET -e2 -Ply np_rPOLYterm -rP res.mod \
	np_rPOLYterm::poly_cut np_rM1term::mt1_cut - rNSDcont,2,t \
	rPOLYcont,1,2,t rPSDcont,2,t NMOS_MOS_21_mgvia,1,z \
	PMOS_MOS_27_mgvia,1,z - L1T0,2,I

#==========================================================#
# Form resistive via layers
#==========================================================#

stamp -V -i2 np_rM1term rPOLYcont np_rPOLYcont
geom -V np_rPOLYcont,p_rPOLYcont - rPOLYcont,1,i,1
stamp -V -B -i np_rM1term NSDcont
/bin/cp -f NSDcont rNSDcont
stamp -V -B -i np_rM1term PSDcont
/bin/cp -f PSDcont rPSDcont

#==========================================================#
# Perform stamp operations
#==========================================================#

stamp -V -cntr -i -B np_rNSDterm np_rNWVIA
stamp -V -maxnet -i -mV -B np_rNWVIA np_rNWELLterm
stamp -V -cntr -i -B np_rPSDterm np_rSUBVIA
stamp -V -maxnet -i -mV -B np_rSUBVIA np_rPSUB

#==========================================================#
# Combine power non-power
#==========================================================#

/bin/rm -f NSDterm
geom np_rNSDterm,p_rNSDterm - NSDterm,1,i,1
epick -c -f floatlvsnetsfile NSDterm NSDterm
/bin/rm -f POLYterm
geom np_rPOLYterm,p_rPOLYterm - POLYterm,1,i,1
epick -c -f floatlvsnetsfile POLYterm POLYterm
/bin/rm -f PSDterm
geom np_rPSDterm,p_rPSDterm - PSDterm,1,i,1
epick -c -f floatlvsnetsfile PSDterm PSDterm
/bin/rm -f NWELLterm
emerge np_rNWELLterm p_rNWELLterm  NWELLterm
epick -c -f floatlvsnetsfile NWELLterm NWELLterm
/bin/rm -f PSUB
emerge np_rPSUB p_rPSUB  PSUB
epick -c -f floatlvsnetsfile PSUB PSUB

#==========================================================#
# Reconnect MOSFET devices
#==========================================================#

reconnect -V -mbg -n NET -se2 mwires.res -mf -t \
	NMOS_MOS_21.trans:NMOS_MOS_21.transr NMOS_MOS_21 \
	NSDterm,NMOS_MOS_21_mgvia,PSUB -t \
	PMOS_MOS_27.trans:PMOS_MOS_27.transr PMOS_MOS_27 \
	PSDterm,PMOS_MOS_27_mgvia,NWELLterm
changeTransFileNameAP NMOS_MOS_21.trans NMOS_MOS_21.transr
changeTransFileNameAP PMOS_MOS_27.trans PMOS_MOS_27.transr
netprint -max NET > original_maxnetfile

#==========================================================#
# Generate netlister data files
#==========================================================#


#==========================================================#
# Perform RC reduction
#==========================================================#

xreduce -V -mergecap -n NET -tech \
	/home/installs/FOUNDRY/analog/180nm/pv/assura/rcx -d1 -e \
	np_rM1term,np_rPOLYterm,np_rPSDterm,np_rNSDterm,np_rPSUB,np_rNWELLterm,rPOLYcont \
	-mfactorR infinite -decoupled -minR 0.001 -rPvia \
	rPOLYcont.res,rPSDcont.res,rNSDcont.res -rP \
	np_rPOLYterm.res,np_rM1term.res,mwires.res L1T0 NMOS_MOS_21.transr \
	PMOS_MOS_27.transr

#==========================================================#
# Generate HSPICE file
#==========================================================#

advgen -V -g0 -li -f -n -o HSPICE -TL L1T0 -sc caps2dversion -rPm res.mod \
	np_rM1term.res,Rnp_rM1term.dev2 np_rPOLYterm.res,Rnp_rPOLYterm.dev2 \
	rPOLYcont.res,RrPOLYcont.dev2 rPSDcont.res,RrPSDcont.dev2 \
	rNSDcont.res,RrNSDcont.dev2 -rPm mwires.mod mwires.res,mwires.dev2 \
	-ta lvsmos.mod,NMOS_MOS_21.net NMOS_MOS_21.transr -ta \
	lvsmos.mod,PMOS_MOS_27.net PMOS_MOS_27.transr - NET - \
	/home/internals/workshop_179/csa/lvs/extview.tmp

#==========================================================#
# Create _save_layers file for Assura extracted view
#==========================================================#

stamp -i2 np_rM1term rPOLYcont np_rPOLYcont
ereduce  rNSDcont rNSDcont.reduce
stamp -i  np_rM1term rNSDcont.reduce
stamp -i  rNSDcont.reduce rNSDcont
stamp -i  rNSDcont NSDcont
/bin/rm -f rNSDcont.reduce
ereduce  rPSDcont rPSDcont.reduce
stamp -i  np_rM1term rPSDcont.reduce
stamp -i  rPSDcont.reduce rPSDcont
stamp -i  rPSDcont PSDcont
/bin/rm -f rPSDcont.reduce
cat <<ENDCAT> _save_layers
M1term np_rM1term p_rM1term
POLYterm np_rPOLYterm p_rPOLYterm
PSDterm np_rPSDterm p_rPSDterm
NSDterm np_rNSDterm p_rNSDterm
PSUB np_rPSUB p_rPSUB
NWELLterm np_rNWELLterm p_rNWELLterm
POLYcont np_rPOLYcont p_rPOLYcont
PSDcont PSDcont
NSDcont NSDcont
NWVIA np_rNWVIA p_rNWVIA
SUBVIA np_rSUBVIA p_rSUBVIA
ENDCAT
